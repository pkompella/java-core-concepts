package com.java.training.rest;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/message")
public class MessageService {
	@GET
	@Path("/{param}")
	public Response getMsg(@PathParam("param") String msg) {
		System.out.println("Came to get Msg method....");
		String output = "Using Jersey @Path Annotation....... -> Message : " + msg;
		return Response.status(200).entity(output).build();
	}

	/**
	 * Multiple Params
	 */
	@GET
	@Path("{year}/{month}/{day}")
	@Produces(MediaType.TEXT_XML)
	public Response getDate(@PathParam("year") int year, @PathParam("month") int month, @PathParam("day") int day) {
		String date = year + "/" + month + "/" + day;
		return Response.status(200).entity("getDate is called, year/month/day : " + date).build();
		
	}

}
