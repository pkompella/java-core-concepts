package com.java.training.rest;

import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;

@Path("/employee")
public class EmployeeService {
	@POST
	@Path("/add")
	public Response addEmployee(@FormParam("id") int id, @FormParam("fname") String fname,
			@FormParam("lname") String lname) {
		return Response.status(200).entity(
				" Employee added successfuly!<br> Id: " + id + "<br> First Name: " + fname + "<br> Last Name: " + lname)
				.build();
	}
}
