package com.java.training.rest;

import java.io.File;
import javax.ws.rs.GET;  
import javax.ws.rs.Path;  
import javax.ws.rs.Produces;  
import javax.ws.rs.core.Response;  
import javax.ws.rs.core.Response.ResponseBuilder;  
@Path("/files")  
public class DownloadService {
	private static final String TXT_FILE_PATH = "c:\\temp\\myfile.txt";  
    @GET  
    @Path("/txt")  
    @Produces("text/plain")  
    public Response getTxtFile() {  
        File file = new File(TXT_FILE_PATH);  
   
        ResponseBuilder response = Response.ok((Object) file);  
        response.header("Content-Disposition","attachment; filename=\"sample_file.txt\"");  
        return response.build();  
   
    }
    
    private static final String IMAGE_FILE_PATH = "c:\\temp\\myimage.png";  
    @GET  
    @Path("/image")  
    @Produces("image/png")  
    public Response getPNGFile() {  
        File file = new File(IMAGE_FILE_PATH);  
        ResponseBuilder response = Response.ok((Object) file);  
        response.header("Content-Disposition","attachment; filename=\"sample_image.png\"");  
        return response.build();  
   
    }
    
    private static final String PDF_FILE_PATH = "c:\\temp\\mypdf.pdf";  
    @GET  
    @Path("/pdf")  
    @Produces("application/pdf")  
    public Response getFile() {  
        File file = new File(PDF_FILE_PATH);  
        ResponseBuilder response = Response.ok((Object) file);  
        response.header("Content-Disposition","attachment; filename=\"sample_pdf.pdf\"");  
        return response.build();  
    }  
}
