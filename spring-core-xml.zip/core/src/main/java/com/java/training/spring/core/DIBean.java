package com.java.training.spring.core;

public class DIBean {
	
	private MessageBean bean1;
	private AnotherOne bean2;

	public void setBean1(MessageBean bean1) {
		this.bean1 = bean1;
	}

	/*public void setBean2(AnotherOne bean2) {
		this.bean2 = bean2;
	}*/
	
	public DIBean() {
		
	}
	
	public DIBean(AnotherOne bean2) {
		this.bean2 = bean2;
	}
	
	public void print() {
		System.out.println("*************** DI Bean ***************");
		bean1.print();
		bean2.print();
	}
	
	

}
