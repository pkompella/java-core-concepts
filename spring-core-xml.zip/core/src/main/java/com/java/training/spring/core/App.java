package com.java.training.spring.core;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext(
				"spring-module.xml");
		//1. Setting Props by using setter
		MessageBean obj = (MessageBean) context.getBean("messageBean");
		obj.print();
		
		
		//2. Setting Props by using constructor
		AnotherOne anotherOne = (AnotherOne) context.getBean("anotherBean");
		anotherOne.print();


		
		
		//3. Injecting Dependencies
		DIBean diBean = (DIBean) context.getBean("diBean");
		diBean.print();
	}
}
