package com.java.training.spring.core;

public class AnotherOne {
	
	private String arg1 = "Argument1";
	private String arg2 = "Argument2";
	private String arg3 = "Argument3";
	
	public AnotherOne() { /*do nothing*/ }
	
	public AnotherOne(String arg1) {
		this.arg1 = arg1;
	}
	public AnotherOne(String arg1, String arg2) {
		this(arg1);
		this.arg2 = arg2;
	}
	
	public AnotherOne(String arg1, String arg2, String arg3) {
		this(arg1, arg2);
		this.arg3 = arg3;
	}
	
	public void print() {
		System.out.println("Argument 1 = " + arg1);
		System.out.println("Argument 2 = " + arg2);
		System.out.println("Argument 3 = " + arg3);
		System.out.println("Object = " + this);
	}
		

}
