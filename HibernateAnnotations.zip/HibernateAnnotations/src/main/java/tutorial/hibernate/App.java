package tutorial.hibernate;

import org.hibernate.Query;
import org.hibernate.Session;
import tutorial.hibernate.domain.Department;
import tutorial.hibernate.domain.NewEmployee;
import tutorial.hibernate.util.HibernateUtil;

import java.util.List;

/**
 * Created by atp1pak on 6/29/2016.
 */
public class App {

    public static void main(String[] args) {

        Session session = HibernateUtil.getSessionFactory().openSession();


        session.beginTransaction();

        Department department = new Department("JAVA");
        session.save(department);

        session.save(new NewEmployee("Param Kompella",department));
        session.save(new NewEmployee("Sushanth Reddy",department));
        session.save(new NewEmployee("Keerthi Reddy",department));
        session.save(new NewEmployee("Sravani Adama",department));
        session.save(new NewEmployee("Sunil Reddy",department));





        Query q = session.createQuery("From NewEmployee ");

        List<NewEmployee> resultList = q.list();
        /*
        System.out.println("num of employess:" + resultList.size());
        for (NewEmployee next : resultList) {
            System.out.println("next employee: " + next);
            //the fetch type makes a difference between LAZY and EAGER
            System.out.println("next department : " + next.getDepartment());
        }*/

        /*
        The cascade = CascadeType.REMOVE makes a difference when deleting the department
         */



        for (NewEmployee emp : resultList) {
            session.delete(emp);
        }
        session.getTransaction().commit();




    }
}
