package tutorial.hibernate.domain;

/**
 * Created by atp1pak on 6/28/2016.
 */
import javax.persistence.*;

@Entity
@Table
public class NewEmployee {
    @Id
    @GeneratedValue
    private Long id;

    private String name;

    @ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
    private Department department;

    public NewEmployee() {}

    public NewEmployee(String name, Department department) {
        this.name = name;
        this.department = department;
    }


    public NewEmployee(String name) {
        this.name = name;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    @Override
    public String toString() {
        return "NewEmployee [id=" + id + ", name=" + name + "]";
    }

}
