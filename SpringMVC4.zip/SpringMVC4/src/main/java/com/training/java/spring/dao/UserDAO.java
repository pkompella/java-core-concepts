package com.training.java.spring.dao;

import java.util.List;

import com.training.java.spring.model.User;

public interface UserDAO {
	 List<User> list();
	
	 User get(int id);
	
	 void saveOrUpdate(User user);
	
	 void delete(int id);
}