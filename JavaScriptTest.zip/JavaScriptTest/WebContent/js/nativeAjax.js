function loadDoc() {
	//alert('came');
  var xhttp = new XMLHttpRequest();
  //xhttp.open("GET", "info.html",true);
  xhttp.open("GET", "empForm.jsp", true);
  xhttp.send();
  xhttp.onreadystatechange = function() {
	  //alert('received');
    if (xhttp.readyState == 4 && xhttp.status == 200) {
     document.getElementById("demo").innerHTML = xhttp.responseText;
    }
  };

} 