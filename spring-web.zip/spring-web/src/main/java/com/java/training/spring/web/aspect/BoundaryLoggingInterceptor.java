package com.java.training.spring.web.aspect;


import org.apache.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;

import java.lang.reflect.Method;

/**
 * Created by IntelliJ IDEA.
 * User: param
 * Date: 3/5/12
 * Time: 12:55 PM
 * To change this template use File | Settings | File Templates.
 */
@Aspect
public class BoundaryLoggingInterceptor {
    private static Logger logger = Logger.getLogger(BoundaryLoggingInterceptor.class);

    @Pointcut(value="execution (public * com.java.training.spring.web..*(..))")
    public void logging() {}
    

    /**
     * Log entering into a method
     * @param jp
     */
    @Before("logging() && @annotation(com.java.training.spring.web.aspect.BoundaryLogger)")
    public void logInvocation(JoinPoint jp) {
        log(jp, "ENTER: ");
    }


    private void log(JoinPoint jp, String beforeAfter) {
    	if (logger.isInfoEnabled()) {
            String className = jp.getTarget().getClass().getName();
            Method met = getMethod(jp);

            // Create the log string with the method name
            StringBuilder builder = new StringBuilder(beforeAfter);
            builder.append(className).append(".");
            builder.append(met.getName()).append("(");
            boolean hasArgs = false;
            for(Object o : jp.getArgs()) {
                if(o != null) {
                    hasArgs = true;
                    builder.append("<").append(o.getClass().getSimpleName()).append(">");
                    builder.append(o.toString());
                    try {
                        builder.append(", ");
                    } catch(NullPointerException e) {
                        builder.append("null, ");
                    }
                }
            }

            if(hasArgs) {
                builder.substring(0, builder.length() - 2);
            }
            builder.append(")");
            logger.info(builder.toString());
        }
    }

    /**
     * Log that we are leaving a method.
     * @param jp
     * @param retVal
     */
    @AfterReturning(pointcut = "logging() && @annotation(com.java.training.spring.web.aspect.BoundaryLogger)", returning = "retVal")
    public void logComplete(JoinPoint jp, Object retVal) {
        log(jp, "EXIT: ");
    }

    /**
     * Get the method that this join point surrounds.
     * Used for logging the entry into a method.
     *
     * @param jp
     * @return
     */
    protected Method getMethod(JoinPoint jp) {
        Method invoked = null;
        try {
            MethodSignature met = (MethodSignature) jp.getSignature();
            invoked = jp.getSourceLocation().getWithinType().getMethod(
                    met.getMethod().getName(),
                    met.getMethod().getParameterTypes());
        } catch(NoSuchMethodException e) {
            logger.error("Unable to get the method for logging");
            // squash it here instead of letting it bubble up.
        }
        return invoked;
    }
}
