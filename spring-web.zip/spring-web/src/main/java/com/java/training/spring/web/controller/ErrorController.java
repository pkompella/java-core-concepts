package com.java.training.spring.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.java.training.spring.web.exception.CustomException;

@Controller
public class ErrorController {
	@RequestMapping(value = "/customError", method = RequestMethod.GET)
	public ModelAndView getCustomError() throws Exception {
		throw new CustomException("E1234", "This is custom message error message");
	}
	
	@RequestMapping(value = "/genericError", method = RequestMethod.GET)
	public ModelAndView getGeneric() throws Exception {
		throw new Exception("This is generic message error message");
	}

	@ExceptionHandler(CustomException.class)
	public ModelAndView handleCustomException(CustomException ex) {

		ModelAndView model = new ModelAndView("error");
		model.addObject("exception", ex);
		return model;

	}

	@ExceptionHandler(Exception.class)
	public ModelAndView handleAllException(Exception ex) {
		ModelAndView model = new ModelAndView("error");
		model.addObject("errorMessage", ex.getMessage());
		return model;
	}

}