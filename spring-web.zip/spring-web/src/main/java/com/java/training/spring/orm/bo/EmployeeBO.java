package com.java.training.spring.orm.bo;

import java.util.List;

import com.java.training.spring.orm.entity.Employee;

public interface EmployeeBO {
	void save(Employee employee);
	
	void update(Employee employee);
	
	void delete(Employee employee);
	
	Employee findByEmployeeId(int empId);
	
	List<Employee> findAll();

}
