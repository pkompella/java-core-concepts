package com.java.training.spring.orm.dao;

import java.util.List;

import com.java.training.spring.orm.entity.Employee;

public interface EmployeeDAO {
	void save(Employee employee);
	
	void update(Employee employee);
	
	void delete(Employee employee);
	
	Employee findByEmpId(int empId);
	
	List<Employee> findAll();

}
