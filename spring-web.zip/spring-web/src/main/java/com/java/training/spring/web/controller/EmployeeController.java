package com.java.training.spring.web.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.java.training.spring.orm.bo.EmployeeBO;
import com.java.training.spring.orm.entity.Employee;

@Controller
public class EmployeeController {
	
	@Autowired
	private EmployeeBO employeeBo;
	
	@RequestMapping(value = "/employees", method = RequestMethod.GET)
	public ModelAndView employees() {
		List<Employee> employees = employeeBo.findAll();
		ModelAndView model = new ModelAndView();
		model.setViewName("employee");
		model.addObject("employees", employees);

		return model;

	}
	
	@RequestMapping(value = "/employees/{id}", method = RequestMethod.GET)
	public ModelAndView employee(@PathVariable("id") Integer id) {
		Employee emp = employeeBo.findByEmployeeId(id);
		ModelAndView model = new ModelAndView();
		model.setViewName("employee");
		List<Employee> employees = new ArrayList<Employee>();
		employees.add(emp);
		model.addObject("employees", employees);

		return model;

	}



}
