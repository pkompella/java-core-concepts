package com.java.training.spring.orm.dao;

import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.java.training.spring.orm.entity.Employee;

public class EmployeeDAOImpl extends HibernateDaoSupport implements EmployeeDAO {

	public void save(Employee employee) {
		getHibernateTemplate().save(employee);
		
	}

	public void update(Employee employee) {
		getHibernateTemplate().update(employee);
		
	}

	public void delete(Employee employee) {
		getHibernateTemplate().delete(employee);
		
	}

	public Employee findByEmpId(int empId) {
		List list = getHibernateTemplate().find(
                "from Employee where id=?",empId
          );
	return (Employee)list.get(0);
	}

	@Override
	public List<Employee> findAll() {
		List <Employee> list = getHibernateTemplate().find("from Employee");
		return list;
	}
	

}
