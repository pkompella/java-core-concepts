package com.java.training.spring.web.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.java.training.spring.web.aspect.BoundaryLogger;
import com.java.training.spring.web.form.Contact;

@Controller
@SessionAttributes
@ComponentScan("com.java.training.spring.web.conttroller")
public class ContactController {

	@Autowired
	private ContactValidator validator;

	@InitBinder
	private void initBinder(WebDataBinder binder) {
		binder.setValidator(validator);
	}
	
	@RequestMapping(value = "/addContact", method = RequestMethod.POST)
	public String addContact(@ModelAttribute("contact") Contact contact, BindingResult result) {

		System.out.println("First Name:" + contact.getFirstName() + "  Last Name:" + contact.getLastName());
		validator.validate(contact, result);

		if (result.hasErrors()) {
			return "contact";
		}

		return "forward:/processResults.html";
	}

	/*@RequestMapping("/contacts")
	public ModelAndView showContacts() {
		Contact contact = new Contact();
		return new ModelAndView("contact", "command", contact);
	}*/
	@BoundaryLogger
	@RequestMapping(value="/contacts", method = RequestMethod.GET)
	public String initForm(Model model){
		Contact contact = new Contact();
		contact.setFirstName("Param");
		model.addAttribute("contact", contact);
		return "contact";
	}
	@BoundaryLogger
	@RequestMapping(value = "/processResults", method = RequestMethod.POST)
	public ModelAndView showResults(@ModelAttribute("contact") Contact contact, BindingResult result) {

		System.out.println("/processResults method called......");
		
		ModelAndView model = new ModelAndView();
		model.setViewName("results");
		model.addObject("contact", contact);
		model.addObject("contact2", "another object");

		return model;
	}
}
