package com.java.training.spring.web.resolver;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by IntelliJ IDEA. User: param Date: 3/6/12 Time: 9:51 AM To change
 * this template use File | Settings | File Templates.
 */
public class LoggingExceptionResolver extends SimpleMappingExceptionResolver {

	private static Logger logger = Logger.getLogger(LoggingExceptionResolver.class);

	@Override
	protected ModelAndView doResolveException(HttpServletRequest request, HttpServletResponse response, Object handler, Exception exception) {
		logger.error(exception.getMessage(), exception);
		return super.doResolveException(request, response, handler, exception);
	}
}
