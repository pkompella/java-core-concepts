package com.java.training.jdbc;

import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.java.training.web.beans.Employee;

public class EmployeeDAO {
	// JDBC driver name and database URL
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	static final String DB_URL = "jdbc:mysql://localhost/Training";

	// Database credentials
	static final String USER = "training";
	static final String PASS = "training123";

	public List<Employee> getEmployees(int id) {
		return getResults(id);

	}
	
	public List<Employee> getEmployees() {
		return getResults(-1);

	}


	private List<Employee> getResults(int empid) {
		List<Employee> employees = new ArrayList<Employee>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			// STEP 2: Register JDBC driver
			Class.forName("com.mysql.jdbc.Driver");

			// STEP 3: Open a connection
			System.out.println("Connecting to database...");
			conn = DriverManager.getConnection(DB_URL, USER, PASS);
			String sql = "SELECT id, fname, lname, age FROM Employee WHERE id = ?";
			if (empid == -1) {
				sql = "SELECT id, fname, lname, age FROM Employee";
			}
			pstmt = conn.prepareStatement(sql);
			// Bind values into the parameters.
			if (empid != -1) {
				pstmt.setInt(1, empid);
			}
			ResultSet rs = pstmt.executeQuery();

			// STEP 5: Extract data from result set
			while (rs.next()) {
				// Retrieve by column name
				Employee employee = new Employee();
				
				int id = rs.getInt("id");
				int age = rs.getInt("age");
				String first = rs.getString("fname");
				String last = rs.getString("lname");
				employee.setId(id);
				employee.setFname(first);
				employee.setLname(last);
				employees.add(employee);
				
			}
			// STEP 6: Clean-up environment
			rs.close();
			pstmt.close();
			conn.close();

		} catch (SQLException se) {
			// Handle errors for JDBC
			System.out.println("Exception occurred..... ==> " + se.getMessage() + "Code =>" + se.getErrorCode());
			se.printStackTrace();
		} catch (Exception e) {
			// Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			// finally block used to close resources
			try {
				if (pstmt != null)
					pstmt.close();
			} catch (SQLException se2) {
			} // nothing we can do
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException se) {
				se.printStackTrace();
			} // end finally try
		} // end try

		return employees;
	}
}
