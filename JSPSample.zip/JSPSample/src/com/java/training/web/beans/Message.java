package com.java.training.web.beans;

public class Message {
	private String msg = "No message";

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}
	
	
	

}
