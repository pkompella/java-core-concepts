package com.java.training.web.tag;

import java.io.IOException;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class MyCustomTag extends SimpleTagSupport {

	private String message;

	public void setMessage(String msg) {
		this.message = msg;
	}

	StringWriter sw = new StringWriter();

	public void doTag() throws JspException, IOException {
		
		if (message != null) {
			/* Use message from attribute */
			JspWriter out = getJspContext().getOut();
			out.println( message );
			//getJspBody().invoke(sw);
			//getJspContext().getOut().println("this is attribute : " + message + " and body: " + sw.toString());

		} else {
			/* use message from the body */
			getJspBody().invoke(sw);
			getJspContext().getOut().println(sw.toString());
		}
		
		

		// get the error list from request
		PageContext pageContext = (PageContext) getJspContext();
		HttpServletRequest request = (HttpServletRequest) pageContext.getRequest();
		List<String> messages = (ArrayList<String>) request.getAttribute("messages");
		JspWriter out = getJspContext().getOut();
		for (String msg : messages) {
			out.println("<p>" + msg + "</p>");
		}
		
		
	}

}
