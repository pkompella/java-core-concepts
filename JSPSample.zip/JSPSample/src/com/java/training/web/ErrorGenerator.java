package com.java.training.web;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ErrorGenerator extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int error = new Random().nextInt(5);
		switch(error) {
		case 0: 
			throw new ServletException(new RuntimeException("Runtime Exception"));
		case 1: 
			throw new ServletException(new IOException("IO Exception"));
		case 2: 
			throw new ServletException(new ServletException("Servlet Exception"));
		case 3: 
			throw new ServletException(new ServletException("Invalid user id/password"));
		case 4: 
			throw new ServletException(new IllegalStateException("Illegal State Exception"));
		default: 
			throw new ServletException(new Error("Other Error"));
		
		}
	    
	}

}
