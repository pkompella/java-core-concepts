package com.java.training.spring.core;

import org.springframework.beans.factory.annotation.Autowired;

public class DIBean {
	@Autowired
	private MessageBean bean1;
	public AnotherOne getBean2() {
		return bean2;
	}

	public void setBean2(AnotherOne bean2) {
		this.bean2 = bean2;
	}

	public MessageBean getBean1() {
		return bean1;
	}

	@Autowired
	private AnotherOne bean2;

	public void setBean1(MessageBean bean1) {
		this.bean1 = bean1;
	}

	/*public void setBean2(AnotherOne bean2) {
		this.bean2 = bean2;
	}*/
	
	public DIBean() {
		
	}
	
	public DIBean (AnotherOne bean2) {
		this.bean2 = bean2;
	}
	
	public void print() {
		System.out.println("*************** DI Bean ***************");
		bean1.print();
		bean2.print();
	}
	
	

}
