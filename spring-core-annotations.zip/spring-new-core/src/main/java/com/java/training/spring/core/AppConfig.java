package com.java.training.spring.core;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration
public class AppConfig {
	@Bean()
	public MessageBean messageBean() {
		MessageBean m = new MessageBean();
		m.setMessage("My bean Message!");
		m.setName("My name");
		return m ;
	}
	
	@Bean
	public DIBean diBean() {
		return new DIBean();
	}
	
	/*@Bean()
	public AnotherOne anotherOne( ) {
		return new AnotherOne();
	}*/
	
	@Bean()
	public AnotherOne anotherOne2() {
		return new AnotherOne("this is arg1", "this is arg2");
	}


}
