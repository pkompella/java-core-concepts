package com.java.training.spring.core;

public class MessageBean {
	private String name;
	private String message;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	public void print() {
		System.out.println("Name of the Bean = " + name);
		System.out.println("Message = " + message);
		System.out.println("Object = " + this);
	}
	
	
	
	
}
