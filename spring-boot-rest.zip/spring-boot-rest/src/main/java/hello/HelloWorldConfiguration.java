package hello;

import net.atpco.translation.Translator;
import net.atpco.translation.lookup.TranslationCache;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelloWorldConfiguration {

	public static void main(String[] args) {
		//for init purpose
		TranslationCache translationCache = TranslationCache.getInstance();
		SpringApplication.run(HelloWorldConfiguration.class, args);
	}

}
