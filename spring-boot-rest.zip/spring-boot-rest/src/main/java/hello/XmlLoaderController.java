package hello;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import javax.xml.bind.JAXBContext;

import net.atpco.translation.CSVFileGenerator;
import net.atpco.translation.Report;
import net.atpco.translation.Translator;
import net.atpco.translation.generated.POCDestination;
import net.atpco.translation.lookup.TranslationCache;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/xml-loader")
public class XmlLoaderController {

	private static final String success_template = "Success, File Size - %s  Fields - %s Groups %s  XML - %s ";
	private static final String failure_template = "Failed, File Size - %s  Fields - %s Groups %s  Message - %s";
	private final AtomicLong counter = new AtomicLong();

	// Fields,Lookups,Format-Fields,Derived-Fields,Groups
	@RequestMapping(method = RequestMethod.GET)
	public @ResponseBody Greeting xmlLoader(
			@RequestParam(value = "File-Size") String fileSize,
			@RequestParam(value = "Fields") String fields,
			@RequestParam(value = "Lookups") String lookups,
			@RequestParam(value = "Format-Fields") String ffields,
			@RequestParam(value = "Derived-Fields") String dfields,
			@RequestParam(value = "Groups") String groups,
			@RequestParam(value = "enableThreads") boolean enableThreads) {
		MessageFormat mf = new MessageFormat(
				"Groups={0}, Fields={1}, Lookups={2}, Format Fields={3}, Derived Fields={4}");
		String message = mf.format(new Object[] { groups, fields, lookups,
				ffields, dfields });

		System.out.println(message);
		Translator translator = new Translator();
		List<Report> reports = new ArrayList<Report>();
		Report report = createReport(fileSize, fields, lookups, ffields, dfields, groups);
		reports.add(report);

		int _fields = Integer.parseInt(fields);
		int _groups = Integer.parseInt(groups);
		int _lookups = Integer.parseInt(lookups);
		int _ffields = Integer.parseInt(ffields);
		int _dfields = Integer.parseInt(dfields);

		String xml = "";
		String msg = "";
		try {
			long start = System.currentTimeMillis();
			xml = translator.translate(TranslationCache.getInstance().getJAXBContext(), fileSize, _fields,
					_lookups, _ffields, _dfields, _groups, enableThreads);
			msg = String
					.format(success_template, fileSize, fields, groups, xml);
			long end = System.currentTimeMillis();
			report.setTime(String.valueOf(end - start));
		} catch (Exception e) {
			xml = e.getMessage();
			msg = String
					.format(failure_template, fileSize, fields, groups, xml);
		}

		message = "XML transformed = " + xml;
		new CSVFileGenerator().generateReport("C:\\Param\\Work\\MessageHub\\Benchmarks\\benchmark-report.csv", reports);
		//System.out.println("XML translated = " + xml);
		return new Greeting(counter.incrementAndGet(), msg);
	}

	private Report createReport(String fileSize, String fields, String lookups, String ffields, String dfields, String groups) {
		Report report = new Report();
		report.setFileSize(fileSize);
		report.setFields(fields);
		report.setLookups(lookups);
		report.setFormatFields(ffields);
		report.setDerivedFields(dfields);
		report.setGroups(groups);
		return report;
	}


}
