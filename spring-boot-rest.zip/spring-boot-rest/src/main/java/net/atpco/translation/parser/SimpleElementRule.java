package net.atpco.translation.parser;

import com.thebuzzmedia.sjxp.XMLParser;
import com.thebuzzmedia.sjxp.rule.DefaultRule;
import com.thebuzzmedia.sjxp.rule.IRule.Type;

public abstract class SimpleElementRule extends DefaultRule {
    public SimpleElementRule(String xpath) {
        super(Type.CHARACTER, xpath);
    }

    @Override
    public void handleParsedCharacters(XMLParser parser, 
                                      String value, Object userObject) {
        onElementFound(parser, value, userObject);
    }
    abstract public void onElementFound(XMLParser parser,  String value, Object userObject);
}