package net.atpco.translation.parser;

import com.thebuzzmedia.sjxp.XMLParser;
import com.thebuzzmedia.sjxp.rule.DefaultRule;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by atp1pak on 3/31/2015.
 */
public class ParserHelper {
    public List getRules(final int fields, final int lookups, final int ffields, final int dfields, final int groups) {
        List<DefaultRule> listOfRules = new ArrayList<DefaultRule>();
        listOfRules.add(new ElementParsedDoneRule("/POCSource/groups/group/fields/field") {

            @Override
            public void onElementStarting(XMLParser parser, int index, String value, Object userObject) {
                boolean canContinue = true;
                POCSource pocSource = (POCSource) userObject;
                if (fields == 0) {
                	canContinue = false;
                }
                if (pocSource.getCurrentGroup().getFields() != null && fields == pocSource.getCurrentGroup().getFields().size()) {
                    //stop field processing as the count reached
                    canContinue = false;
                    if (pocSource.getGroups().size() == groups) {
                        //stop the entire parsing as the group count also reached
                        //parser.stop();
                        //return;
                    }
                }

                if (canContinue) {
                    pocSource.getCurrentGroup().prepareForField();
                }

            }

            @Override
            public void onElementEnding(XMLParser parser, int index, String value, Object userObject) {
                // TODO Auto-generated method stub

            }

        });


        listOfRules.add(new SimpleElementRule("/POCSource/groups/group/fields/field") {

            @Override
            public void onElementFound(XMLParser parser, String value, Object userObject) {
                POCSource pocSource = (POCSource) userObject;
                pocSource.getCurrentGroup().getCurrentField().setValue(value);
           }

        });
        
        
        //for lookups
        listOfRules.add(new ElementParsedDoneRule("/POCSource/groups/group/lookups/lookup") {

            @Override
            public void onElementStarting(XMLParser parser, int index, String value, Object userObject) {
                boolean canContinue = true;
                POCSource pocSource = (POCSource) userObject;
                if (lookups == 0) {
                	canContinue = false;
                }

                if (pocSource.getCurrentGroup().getLookups() != null && lookups == pocSource.getCurrentGroup().getLookups().size()) {
                    //stop field processing as the count reached
                    canContinue = false;
                    if (pocSource.getGroups().size() == groups) {
                        //stop the entire parsing as the group count also reached
                        //parser.stop();
                        //return;
                    }
                }

                if (canContinue) {
                    pocSource.getCurrentGroup().prepareForLookup();
                }

            }

            @Override
            public void onElementEnding(XMLParser parser, int index, String value, Object userObject) {
                // TODO Auto-generated method stub

            }

        });


        listOfRules.add(new SimpleElementRule("/POCSource/groups/group/lookups/lookup") {

            @Override
            public void onElementFound(XMLParser parser, String value, Object userObject) {
                POCSource pocSource = (POCSource) userObject;
                if (pocSource.getCurrentGroup().getLookups() != null) {
                	pocSource.getCurrentGroup().getCurrentLookup().setValue(value);
                }
                //System.out.println("Lookup Key = " + value);
           }

        });
        
      //for format fields
        listOfRules.add(new ElementParsedDoneRule("/POCSource/groups/group/format-fields/ffield") {

            @Override
            public void onElementStarting(XMLParser parser, int index, String value, Object userObject) {
                boolean canContinue = true;
                POCSource pocSource = (POCSource) userObject;
                if (ffields == 0) {
                	canContinue = false;
                }

                if (pocSource.getCurrentGroup().getFormatFields() != null && ffields == pocSource.getCurrentGroup().getFormatFields().size()) {
                    //stop field processing as the count reached
                    canContinue = false;
                    if (pocSource.getGroups().size() == groups) {
                        //stop the entire parsing as the group count also reached
                        //parser.stop();
                        //return;
                    }
                }

                if (canContinue) {
                    pocSource.getCurrentGroup().prepareForFormatField();
                }

            }

            @Override
            public void onElementEnding(XMLParser parser, int index, String value, Object userObject) {
                // TODO Auto-generated method stub

            }

        });


        listOfRules.add(new SimpleElementRule("/POCSource/groups/group/format-fields/ffield") {

            @Override
            public void onElementFound(XMLParser parser, String value, Object userObject) {
                POCSource pocSource = (POCSource) userObject;
                if (pocSource.getCurrentGroup().getFormatFields() != null) {
                	pocSource.getCurrentGroup().getCurrentFormatField().setValue(value);
                }
           }

        });
        
      //for derived fields
        listOfRules.add(new ElementParsedDoneRule("/POCSource/groups/group/derived-fields/dfield") {

            @Override
            public void onElementStarting(XMLParser parser, int index, String value, Object userObject) {
                boolean canContinue = true;
                POCSource pocSource = (POCSource) userObject;
                if (dfields == 0) {
                	canContinue = false;
                }

                if (pocSource.getCurrentGroup().getDerivedFields() != null && dfields == pocSource.getCurrentGroup().getDerivedFields().size()) {
                    //stop field processing as the count reached
                    canContinue = false;
                    if (pocSource.getGroups().size() == groups) {
                        //stop the entire parsing as the group count also reached
                        //parser.stop();
                        //return;
                    }
                }

                if (canContinue) {
                    pocSource.getCurrentGroup().prepareForDerivedField();
                }

            }

            @Override
            public void onElementEnding(XMLParser parser, int index, String value, Object userObject) {
                // TODO Auto-generated method stub

            }

        });


        listOfRules.add(new SimpleElementRule("/POCSource/groups/group/derived-fields/dfield") {

            @Override
            public void onElementFound(XMLParser parser, String value, Object userObject) {
                POCSource pocSource = (POCSource) userObject;
                pocSource.getCurrentGroup().getCurrentDerivedField().setValue(value);
           }

        });
        
      //get the groups
        listOfRules.add(new ElementParsedDoneRule("/POCSource/groups/group") {

            @Override
            public void onElementStarting(XMLParser parser, int index, String value, Object userObject) {
                boolean canContinue = true;
                POCSource pocSource = (POCSource) userObject;
                if (pocSource.getGroups() != null && groups == pocSource.getGroups().size()) {
                    //parser.stop();
                    canContinue = false;
                }

                if (canContinue) {
                    pocSource.prepareForGroup();
                }

            }

            @Override
            public void onElementEnding(XMLParser parser, int index, String value, Object userObject) {
                // TODO Auto-generated method stub

            }

        });



        return listOfRules;

    }
}
