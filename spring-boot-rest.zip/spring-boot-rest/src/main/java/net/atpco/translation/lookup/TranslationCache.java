package net.atpco.translation.lookup;

import javax.xml.bind.JAXBContext;

import net.atpco.translation.generated.POCDestination;
import net.atpco.translation.util.SystemMetrics;

public class TranslationCache {
	private static TranslationCache translationCache = new TranslationCache();
	private static JAXBContext jaxbContext = initJAXBContext();
	private static LookupService[] lookupServices = initLookupServices();

	private TranslationCache() {
	}

	public static TranslationCache getInstance() {
		return translationCache;
	}

	public JAXBContext getJAXBContext() {
		return jaxbContext;
	}

	public LookupService[] getLookupServices() {
		return lookupServices;
	}

	private static JAXBContext initJAXBContext() {
		SystemMetrics.getInstance().sysOut("\n########### Called initJAXBContext  #################");
		try {
			return JAXBContext.newInstance(POCDestination.class);
		} catch (Exception e) {
		}
		return null;

	}

	private static LookupService[] initLookupServices() {
		SystemMetrics.getInstance().sysOut("\n########### Called initLookupServices #################");
		lookupServices = new LookupService[] { LookupService1.getInstance(),
				LookupService2.getInstance(), LookupService3.getInstance(),
				LookupService4.getInstance(), LookupService5.getInstance(),
				LookupService6.getInstance(), LookupService7.getInstance(),
				LookupService8.getInstance(), LookupService9.getInstance(),
				LookupService10.getInstance() };
		return lookupServices;
	}

}
