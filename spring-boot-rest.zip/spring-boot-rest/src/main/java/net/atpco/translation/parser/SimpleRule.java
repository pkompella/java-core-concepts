package net.atpco.translation.parser;

import com.thebuzzmedia.sjxp.XMLParser;
import com.thebuzzmedia.sjxp.rule.DefaultRule;
import com.thebuzzmedia.sjxp.rule.IRule.Type;

public abstract class SimpleRule extends DefaultRule {
    public SimpleRule(String xpath, String... attrNames) {
        super(Type.ATTRIBUTE, xpath, attrNames);
    }

    @Override
    public void handleParsedAttribute(XMLParser parser, int index,
                                      String value, Object userObject) {
    	//System.out.println("in handleParsedAttribute ==> value = " + value);
        onAttributeFound(parser, index,                 value, userObject);
    }
    abstract public void onAttributeFound(XMLParser parser, int index, String value, Object userObject);
}