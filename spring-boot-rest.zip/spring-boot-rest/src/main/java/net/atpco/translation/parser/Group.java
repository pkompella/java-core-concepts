package net.atpco.translation.parser;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by atp1pak on 3/31/2015.
 */
public class Group {
    @Getter @Setter
    private List<Field> fields;
    @Getter @Setter
    private List<Lookup> lookups;
    @Getter @Setter
    private List<Derived> derivedFields;
    @Getter @Setter
    private List<FormatField> formatFields;

    public Field getCurrentField() {
        return fields.get(fields.size()-1);
    }
    public void prepareForField() {
        if (fields==null){
            fields = new ArrayList<Field>();
        }
        Field current = new Field();
        fields.add(current);
    }
    public Lookup getCurrentLookup() {
        return lookups.get(lookups.size()-1);
    }
    public void prepareForLookup() {
        if (lookups==null){
        	lookups = new ArrayList<Lookup>();
        }
        Lookup current = new Lookup();
        lookups.add(current);
    }
    public  FormatField getCurrentFormatField() {
        return formatFields.get(formatFields.size()-1);
    }
    public void prepareForFormatField() {
        if (formatFields==null){
        	formatFields = new ArrayList<FormatField>();
        }
        FormatField current = new FormatField();
        formatFields.add(current);
    }
    public  Derived getCurrentDerivedField() {
        return derivedFields.get(derivedFields.size()-1);
    }
    public void prepareForDerivedField() {
        if (derivedFields==null){
        	derivedFields = new ArrayList<Derived>();
        }
        Derived current = new Derived();
        derivedFields.add(current);
    }

}
