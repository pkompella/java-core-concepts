package net.atpco.translation.parser;

import lombok.Getter;
import lombok.Setter;

/**
 * Created by atp1pak on 3/31/2015.
 */
public class Derived {
    @Getter
    @Setter
    private String value;
}
