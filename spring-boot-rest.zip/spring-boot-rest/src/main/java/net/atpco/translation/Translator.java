package net.atpco.translation;

import java.io.InputStream;
import java.io.StringWriter;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;

import net.atpco.translation.format.FormatHelper;
import net.atpco.translation.generated.Description;
import net.atpco.translation.generated.Descriptions;
import net.atpco.translation.generated.FormatFields;
import net.atpco.translation.generated.POCDestination;
import net.atpco.translation.generated.Result;
import net.atpco.translation.generated.Results;
import net.atpco.translation.generated.Values;
import net.atpco.translation.lookup.TranslationCache;
import net.atpco.translation.parser.CustomParser;
import net.atpco.translation.parser.Field;
import net.atpco.translation.parser.FormatField;
import net.atpco.translation.parser.Group;
import net.atpco.translation.parser.Lookup;
import net.atpco.translation.parser.POCSource;
import net.atpco.translation.util.SystemMetrics;

/**
 * Created by atp1pak on 3/31/2015.
 */
public class Translator {

    public String translate(JAXBContext jaxbContext, String fileSize, Integer fields, Integer lookups, Integer ffields, Integer dfields, Integer groups, boolean enableThreads) throws Exception {
        SystemMetrics.getInstance().startXML2ObjMetric();
        //0. create InputSource from message
        InputStream source = new InputFileReader().getSource(fileSize, fields, groups);
         //1. parse the xml
        POCSource parsedObject = new CustomParser().parse(source, fields, lookups, ffields, dfields, groups);
        SystemMetrics.getInstance().endXML2ObjMetric();

        //SystemMetrics.getInstance().sysOut("XML2 Object Time = " + (end - start));
        //2. transform the parsed object to destination obj
        SystemMetrics.getInstance().startObj2ObjMetric();
        POCDestination destination = transform(parsedObject, enableThreads);
        SystemMetrics.getInstance().endObj2ObjMetric();
        //SystemMetrics.getInstance().sysOut("Object 2 Object Time = " + (end - start));

        //3. get the XML from the destination object
        SystemMetrics.getInstance().startObj2XMLMetric();
        Marshaller m = jaxbContext.createMarshaller();
        StringWriter sw = new StringWriter();
        //m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
        m.marshal(destination, sw);
        SystemMetrics.getInstance().endObj2XMLMetric();
        //SystemMetrics.getInstance().sysOut("Object 2 XML Time = " + (end - start));
        return sw.toString();

    }

    private POCDestination transform(POCSource source, boolean enableThreads) {
    	POCDestination destination = new POCDestination();
        
        //SystemMetrics.getInstance().sysOut("Groups count = " + source.getGroups().size());
        if (enableThreads) {
        	SystemMetrics.getInstance().sysOut("\nThreads Enabled....");
        	transformParallel(source, destination);
        	SystemMetrics.getInstance().sysOut("\nResult Count # ==> " + destination.getResults().getResult().size());
        } else {
        	SystemMetrics.getInstance().sysOut("\nThreads Disabled....");
        	Results results = new Results();
            //destination.setResults(results);
	        for (Group group: source.getGroups()) {
	            Result result = new Result();
	            result.setValues(getValues(group.getFields()));
	            if (group.getLookups() != null ) result.setDescriptions(getDescriptions(group.getLookups()));
	            if (group.getFormatFields() != null ) result.setFormatFields(getFormattedValues(group.getFormatFields()));
	            if (group.getDerivedFields() != null )result.setAllDerived("Count = " + group.getDerivedFields().size());
	            results.getResult().add(result);
	        }
	        destination.setResults(results);
        }
        

        return destination;
    }

    private void transformParallel(POCSource source, POCDestination destination) {
    	Results results = new Results();
    	for (Group group: source.getGroups()) {
    		results.getResult().add(new Result());
    	}
    	destination.setResults(results);
    	ExecutorService executor = Executors.newFixedThreadPool(4);
        Runnable runnable[] = new Runnable[4];
        runnable[0] = new TransformDirectFields(source, results);
        runnable[1] = new TransformLookupFields(source, results);
        runnable[2] = new TransformFormatFields(source, results);
        runnable[3] = new TransformDerivedFields(source, results);
               
        for (int i = 0; i < 4; i++) {
            Runnable worker = runnable[i];
            executor.execute(worker);
        }
        executor.shutdown();
        // Wait until all threads are finish
        while (!executor.isTerminated()) {

        }
        SystemMetrics.getInstance().sysOut("\nFinished all threads");
        
		
	}

	private FormatFields getFormattedValues(List<FormatField> formatFields) {
    	FormatFields fields = new FormatFields();
        int index = 1;
        FormatHelper formatHelper = new FormatHelper();
    	for (FormatField field : formatFields) {
    		fields.getFormatField().add(formatHelper.format(field.getValue()) + " Count = " + index++);
    	}
		return fields;
	}

	

	private Values getValues(List<Field> fields) {
        Values values = new Values();
        int index = 1;
        for (Field field : fields) {
            values.getValue().add(field.getValue() + " Count = " + index++);
        }
        return values;
    }
    
    private Descriptions getDescriptions(List<Lookup> lookups) {
    	Descriptions descriptions = new Descriptions();
        int index = 1;
        for (Lookup lookup : lookups) {
        	Description desc = new Description();
        	desc.setCode(lookup.getValue() + " Count = " + index++);
        	desc.setDescText(getLookupDescription(lookup.getValue()));
        	descriptions.getDescription().add(desc);
        }
        return descriptions;
    }
    
    private String getLookupDescription(String key) {
    	int serviceIndex = randomize(1, 10);
    	int lookupIndex = randomize(1, 10000);
    	//SystemMetrics.getInstance().sysOut("Key = " + key+ ":" + lookupIndex);
    	return TranslationCache.getInstance().getLookupServices()[serviceIndex-1].lookup(key+ ":" + lookupIndex);
    }
    
    private  int randomize(int min, int max) {
		// Usually this can be a field rather than a method variable
		Random rand = new Random();
		// nextInt is normally exclusive of the top value,
		// so add 1 to make it inclusive
		int randomNum = rand.nextInt((max - min) + 1) + min;
		return randomNum;
	}
    
    class TransformDirectFields implements Runnable {
    	POCSource source;
    	Results results;

    	TransformDirectFields(POCSource source, Results results) {
            this.source = source;
            this.results = results;
        }

        @Override
        public void run() {
        	for (Group group: this.source.getGroups()) {
        		for (Result result: results.getResult()) {
		            result.setValues(getValues(group.getFields()));
	        	}
         	}
        }
    }
    
    class TransformLookupFields implements Runnable {
    	POCSource source;
    	Results results;

    	TransformLookupFields(POCSource source, Results results) {
            this.source = source;
            this.results = results;
        }

        @Override
        public void run() {
        	for (Group group: this.source.getGroups()) {
        		for (Result result: results.getResult()) {
        			if (group.getLookups() != null ) result.setDescriptions(getDescriptions(group.getLookups()));
	        	}
        	}
        }
    }
    
    class TransformFormatFields implements Runnable {
    	POCSource source;
    	Results results;

    	TransformFormatFields(POCSource source, Results results) {
            this.source = source;
            this.results = results;
        }

        @Override
        public void run() {
        	for (Group group: this.source.getGroups()) {
        		for (Result result: results.getResult()) {
        			if (group.getFormatFields() != null ) result.setFormatFields(getFormattedValues(group.getFormatFields()));
	        	}
        	}
        }
    }
    
    class TransformDerivedFields implements Runnable {
    	POCSource source;
    	Results results;

    	TransformDerivedFields(POCSource source, Results results) {
            this.source = source;
            this.results = results;
        }

        @Override
        public void run() {
        	for (Group group: this.source.getGroups()) {
        		for (Result result: results.getResult()) {
        			if (group.getDerivedFields() != null )result.setAllDerived("Count = " + group.getDerivedFields().size());
	        	}
         	}
        }
    }


}
