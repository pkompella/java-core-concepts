package net.atpco.translation;

import java.io.FileInputStream;
import java.io.InputStream;
import java.text.MessageFormat;

/**
 * Created by atp1pak on 3/31/2015.
 */
public class InputFileReader {
    String path = "C:\\Workspaces\\spring-boot-rest\\src\\main\\resources\\";
    public InputStream getSource(String fileSize, Integer fields, Integer groups) throws Exception {
        /*File f = new File(fileName);
        FileInputStream fis = new FileInputStream(f);
        byte[] b = new byte[(int) f.length()];
        fis.read(b);*/
        MessageFormat mf = new MessageFormat("POCSource-{0}f-{1}g.xml");
        Object[] values = null;
        if ("XS".equals(fileSize)) {
        	values = new Object[]{String.valueOf(25), String.valueOf(25)};
        } else if ("S".equals(fileSize)) {
        	values = new Object[]{String.valueOf(50), String.valueOf(50)};
        } else if ("M".equals(fileSize)) {
        	values = new Object[]{String.valueOf(75), String.valueOf(75)};
        } else if ("L".equals(fileSize)) {
        	values = new Object[]{String.valueOf(99), String.valueOf(99)};
        }
        String fileName = mf.format(values);
        
        //fileName = "POCSource-Med.xml";
        //InputStream source = new FileInputStream(path + fileName);
        InputStream source = this.getClass().getClassLoader().getResourceAsStream(fileName);
        return source;

    }
}
