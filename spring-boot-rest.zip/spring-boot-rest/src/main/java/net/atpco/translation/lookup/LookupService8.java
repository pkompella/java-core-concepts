package net.atpco.translation.lookup;

import java.util.HashMap;
import java.util.Map;

public class LookupService8 implements LookupService {
	private static LookupService8 lookupService = null;
	private Map<String, String> serviceMap = new HashMap<>();
    private LookupService8() {
    	//load 10K records in to Map
    	for (int i = 0; i < 10000; i++) {
    		String key = "lookup 1:" + (i+1);
        	serviceMap.put(key, "For Key Code:" + key + ",  Descr: Zone Description " + (i+1));
        }
    }
    
    public static LookupService getInstance() {
        if (lookupService == null) {
            lookupService = new LookupService8();
        }
        return lookupService;
    }
    
    public String lookup(String key) {
        return serviceMap.get(key);
    }

}
