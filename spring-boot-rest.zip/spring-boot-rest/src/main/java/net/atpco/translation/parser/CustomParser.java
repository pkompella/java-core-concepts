package net.atpco.translation.parser;

import java.io.InputStream;
import java.util.List;

import com.thebuzzmedia.sjxp.XMLParser;
import com.thebuzzmedia.sjxp.rule.DefaultRule;
import com.thebuzzmedia.sjxp.rule.IRule;
import net.atpco.translation.util.SystemMetrics;

/**
 * Created by atp1pak on 3/31/2015.
 */
public class CustomParser {
    @SuppressWarnings("rawtypes")
	public POCSource parse(InputStream source, int fields, int lookups, int ffields, int dfields, int groups) throws Exception {
        System.setProperty("sjxp.namespaces", "false");
        POCSource parsedObject = new POCSource();
        //@SuppressWarnings("unchecked")
		List<DefaultRule> listOfRules = new ParserHelper().getRules(fields, lookups, ffields, dfields, groups);
        IRule[] rulesArray = new IRule[listOfRules.size()];
        //@SuppressWarnings("unchecked")
		XMLParser<POCSource> parser = new XMLParser<POCSource>(listOfRules.toArray(rulesArray));
        parser.parse(source, parsedObject);
        SystemMetrics.getInstance().sysOut("^^^^^^^^^^^ Groups Size = " + parsedObject.getGroups().size());
        SystemMetrics.getInstance().sysOut("*********** Fields Size = " + parsedObject.getGroups().get(0).getFields().size());
        SystemMetrics.getInstance().sysOut("########### Lookups Size = " + parsedObject.getGroups().get(0).getLookups().size());
        SystemMetrics.getInstance().sysOut("$$$$$$$$$$$ Formated Fields Size = " + parsedObject.getGroups().get(0).getFormatFields().size());
        SystemMetrics.getInstance().sysOut("@@@@@@@@@@@ Derived Fields Size = " + parsedObject.getGroups().get(0).getDerivedFields().size());

        return parsedObject;
    }


}
