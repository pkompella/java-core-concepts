package net.atpco.translation.format;

import java.text.SimpleDateFormat;
import java.util.Random;

public class FormatHelper {

	public static void formatMain(String[] args) {
		for (int i = 0; i < 100; i++) {
			System.out.println("Value = " + new FormatHelper().format("Param Kompella"));
		}
	}

	public String format(String field) {
		String result = "";
		int formatMode = randomize(1, 10);

		//System.out.println("Random # = " + formatMode);
		try {
			switch (formatMode) {
				case 1: {
					SimpleDateFormat df = new SimpleDateFormat("yyyy.MM.dd G 'at' HH:mm:ss z");
					String dateStr = "2010.06.07 AD at 21:00:18 EST";
					result = df.parse(dateStr).toString();
				//result = field.toLowerCase();
					break;
				}
				case 2: {
					//result = field.toUpperCase();
					SimpleDateFormat df = new SimpleDateFormat("yyyyy.MMMMM.dd GGG hh:mm aaa");
					String dateStr = "02010.June.07 AD 09:00 PM";
					result = df.parse(dateStr).toString();
					break;
				}
				case 3: {
					SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
					String dateStr = "2010-06-07T21:00:18.668-0500";
					result = df.parse(dateStr).toString();
					//result = field.substring(0, 2).concat(field);
					break;
				}
				case 4: {
					//result = field.replace("value", "eulav");
					SimpleDateFormat df = new SimpleDateFormat("EEE, d MMM yyyy HH:mm:ss Z");
					String dateStr = "Mon, 7 Jun 2010 21:00:18 -0500";
					result = df.parse(dateStr).toString();
					break;
				}
				case 5: {
					//result = field.substring(6).toLowerCase();
					SimpleDateFormat df = new SimpleDateFormat("yyMMddHHmmssZ");
					String dateStr = "100607210018-0500";
					result = df.parse(dateStr).toString();
					break;
				}
				case 6: {
					//result = field.substring(6).toUpperCase();
					SimpleDateFormat df = new SimpleDateFormat("hh 'o''clock' a, zzzz");
					String dateStr = "09 o'clock PM, Central Daylight Time";
					result = df.parse(dateStr).toString();
					break;
				}
				case 7: {
					//result = new StringBuilder(field).reverse().toString();
					SimpleDateFormat df = new SimpleDateFormat("EEE, MMM d, ''yy");
					String dateStr = "Mon, Jun 7, '10";
					result = df.parse(dateStr).toString();
					break;
				}
				case 8: {
					//result = new StringBuilder(field).reverse().toString()
					//		.toUpperCase();
					SimpleDateFormat df = new SimpleDateFormat("H:mm:ss:SSS");
					String dateStr = "21:00:18:668";
					result = df.parse(dateStr).toString();
					break;
				}
				case 9: {
					//result = new StringBuilder(field).reverse().toString()
					//		.toLowerCase();
					SimpleDateFormat df = new SimpleDateFormat("dd.MM.yy");
					String dateStr = "07.06.10";
					result = df.parse(dateStr).toString();
					break;
				}
				case 10: {
					//result = new StringBuilder(field).reverse().subSequence(0, 5)
					//		.toString();
					SimpleDateFormat df = new SimpleDateFormat("K:mm a, z");
					String dateStr = "9:00 PM, CDT";
					result = df.parse(dateStr).toString();
					break;
				}
				default: {
					result = "not formatted!";
					break;
				}
			}
		} catch (Exception e) {
			System.out.println("Error parsing.....");
		}
		return result;
	}

	private static int randomize(int min, int max) {
		// Usually this can be a field rather than a method variable
		Random rand = new Random();
		// nextInt is normally exclusive of the top value,
		// so add 1 to make it inclusive
		int randomNum = rand.nextInt((max - min) + 1) + min;
		return randomNum;
	}

}
