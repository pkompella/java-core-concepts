package net.atpco.translation;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBContext;

import net.atpco.translation.generated.POCDestination;
import net.atpco.translation.lookup.TranslationCache;
import net.atpco.translation.util.SystemMetrics;
import org.junit.Test;
import org.springframework.boot.test.IntegrationTest;

public class Main {
	static final int FIELDS_MAX = 50;
	static final int GROUPS_MAX = 50;
	static final int LOOP_COUNT = 100;

	@Test
	public void translateThis() throws Exception {
		TranslationCache translationCache = TranslationCache.getInstance();
		SystemMetrics systemMetrics = SystemMetrics.getInstance();
		Translator translator = new Translator();
		JAXBContext jaxbContext = translationCache.getJAXBContext();
		double time = 0;
		//int field = fields[0];
		//long start = System.nanoTime();
		for (int i = 0; i < 100; i++) {
			String xml = translator.translate(jaxbContext, "M", 10, 10, 10, 10, 10, false);
		}
		//long end = System.nanoTime();

		//SystemMetrics.getInstance().sysOut("Total Time took = " + (end-start));
		SystemMetrics.getInstance().print(false);
		//System.out.println("Total Time took = "); System.out.printf("%.0f", (double)(end-start));
	}

	@Test
	public void findFilePath() {
		String absolute = getClass().getProtectionDomain().getCodeSource().getLocation().toExternalForm();
		absolute = absolute.substring(0, absolute.length() - 1);
		absolute = absolute.substring(0, absolute.lastIndexOf("/") + 1);
		String configPath = absolute + "resources/file.properties";
		String os = System.getProperty("os.name");
		if (os.indexOf("Windows") != -1) {
			configPath = configPath.replace("/", "\\\\");
			if (configPath.indexOf("file:\\\\") != -1) {
				configPath = configPath.replace("file:\\\\", "");
			}
		} else if (configPath.indexOf("file:") != -1) {
			configPath = configPath.replace("file:", "");
		}
		System.out.println("Config file path = " + configPath);
		InputStream classLoaderPath = this.getClass().getClassLoader().getResourceAsStream("POCSource-25f-25g.xml");
		System.out.println("classLoaderPath = " + classLoaderPath.toString());
	}

	private static void removeFiles() {
		File folder = new File(
				"C:\\TEMP\\MessageHub\\code-transform\\new-benchmark");
		File[] files = folder.listFiles();
		for (File f : files) {
			f.delete();
		}

	}

	private static void translate(int fields, int lookups, int ffields, int dfields, int groups,
			Translator translator, JAXBContext jaxbContext, List<Report> reports)
			throws Exception {
		Report report = new Report();
		reports.add(report);
		report.setFileSize("1.01 MB");
		report.setFields(String.valueOf(fields));

		report.setGroups(String.valueOf(groups));
		String xml = "";
		long averageTime = 0;
		long start = System.nanoTime();
		xml = translator.translate(jaxbContext, "XS", fields, lookups, ffields, dfields, groups, false);
		long end = System.nanoTime();
		report.setTime(String.valueOf(averageTime / LOOP_COUNT) + " ms");
		createOutputFile(fields, groups, xml);
	}

	private static void createOutputFile(int fields, int groups, String xml)
			throws Exception {
		MessageFormat mf = new MessageFormat("Output-{0}f-{1}g.xml");
		String fileName = mf.format(new Object[] { String.valueOf(fields),
				String.valueOf(groups) });
		FileOutputStream fos = new FileOutputStream(
				"C:\\TEMP\\MessageHub\\code-transform\\new-benchmark\\"
						+ fileName);
		fos.write(xml.getBytes());
		fos.flush();
		fos.close();
	}
}
