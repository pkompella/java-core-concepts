package net.atpco.translation;

import lombok.Getter;
import lombok.Setter;

/**
 * Created by atp1pak on 4/1/2015.
 */
public class Report {
    @Getter
    @Setter
    private String fields;

    @Getter
    @Setter
    private String groups;

    @Getter
    @Setter
    private String time;

    @Getter
    @Setter
    private String fileSize;

    @Getter
    @Setter
    private String formatFields;

    @Getter
    @Setter
    private String derivedFields;

    @Getter
    @Setter
    private String lookups;
}
