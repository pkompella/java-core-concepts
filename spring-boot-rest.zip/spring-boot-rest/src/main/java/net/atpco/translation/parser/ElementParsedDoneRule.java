package net.atpco.translation.parser;

import com.thebuzzmedia.sjxp.XMLParser;
import com.thebuzzmedia.sjxp.rule.DefaultRule;
import com.thebuzzmedia.sjxp.rule.IRule.Type;

public abstract class ElementParsedDoneRule extends DefaultRule {
    public ElementParsedDoneRule(String xpath) {
        super(Type.TAG, xpath, null);
    }

        
    public void handleTag(XMLParser parser, boolean isStartTag, Object userObject){
    	
       if (isStartTag){
    	   onElementStarting(parser, 0, null, userObject);   
       }else{
    	   onElementEnding(parser, 0, null, userObject);   
       }
        
    }
    abstract public void onElementStarting(XMLParser parser, int index, String value, Object userObject);
    abstract public void onElementEnding(XMLParser parser, int index, String value, Object userObject);
}