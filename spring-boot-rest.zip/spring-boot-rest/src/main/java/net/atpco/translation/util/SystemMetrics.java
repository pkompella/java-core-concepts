package net.atpco.translation.util;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import static java.util.concurrent.TimeUnit.NANOSECONDS;

/**
 * Created by atp1pak on 4/10/2015.
 */
public class SystemMetrics {
    private static SystemMetrics systemMetrics = new SystemMetrics();
    private StringBuilder metricsBuilder = new StringBuilder();
    private List<Long> xml2ObjectMetrics = new ArrayList<>();
    private List<Long> obj2ObjMetrics = new ArrayList<>();
    private List<Long> obj2XmlMetrics = new ArrayList<>();
    private Long getCurrentXML2ObjectMetric() {
        return xml2ObjectMetrics.get(xml2ObjectMetrics.size()-1);
    }
    private void setCurrentXML2ObjectMetric(long value) {
        xml2ObjectMetrics.set(xml2ObjectMetrics.size()-1, value);
    }
    private Long getCurrentObj2ObjMetric() {
        return obj2ObjMetrics.get(obj2ObjMetrics.size()-1);
    }
    private void setCurrentObj2ObjMetric(long value) {
        obj2ObjMetrics.set(obj2ObjMetrics.size()-1, value);
    }
    private Long getCurrentObj2XMLMetric() {
        return obj2XmlMetrics.get(obj2XmlMetrics.size()-1);
    }
    private void setCurrentObj2XMLMetric(long value) {
        obj2XmlMetrics.set(obj2XmlMetrics.size()-1, value);
    }
    /*public void prepareXML2ObjectMetric(long start) {
        if (xml2ObjectMetrics==null){
            xml2ObjectMetrics = new ArrayList<Long>();
        }
        Long current = new Long(start);
        xml2ObjectMetrics.add(current);
    }*/
    private SystemMetrics() { }


    public static SystemMetrics getInstance() {
        return systemMetrics;
    }

    public synchronized StringBuilder getMetricsBuilder() {
        return metricsBuilder;
    }

    public synchronized void sysOut(String s) {
        metricsBuilder.append(s).append("\n");
    }
    public synchronized void startXML2ObjMetric() {
      xml2ObjectMetrics.add(System.nanoTime());
    }
    public synchronized void endXML2ObjMetric() {
        long end = System.nanoTime();
        long start = getCurrentXML2ObjectMetric();
        setCurrentXML2ObjectMetric(end - start);
    }
    public synchronized void startObj2ObjMetric() {
        obj2ObjMetrics.add(System.nanoTime());
    }
    public synchronized void endObj2ObjMetric() {
        long end = System.nanoTime();
        long start = getCurrentObj2ObjMetric();
        setCurrentObj2ObjMetric(end - start);
    }
    public synchronized void startObj2XMLMetric() {
        obj2XmlMetrics.add(System.nanoTime());
    }
    public synchronized void endObj2XMLMetric() {
        long end = System.nanoTime();
        long start = getCurrentObj2XMLMetric();
        setCurrentObj2XMLMetric(end - start);
    }

    public void reset() {
        obj2XmlMetrics = new ArrayList<>();
        obj2ObjMetrics = new ArrayList<>();
        xml2ObjectMetrics = new ArrayList<>();
    }


    public void print(boolean enableLog) {
        double xml2ObjTime = avgTime(xml2ObjectMetrics);
        double obj2ObjTime = avgTime(obj2ObjMetrics);
        double obj2XmlTime = avgTime(obj2XmlMetrics);
        double totalTime = xml2ObjTime + obj2ObjTime + obj2XmlTime;
        System.out.println("**************         START METRICS PRINT     **********************");
        System.out.print("XML2 Object Time = ");
        System.out.printf("%.0f", xml2ObjTime);
        System.out.println("");
        System.out.print("Object 2 Object Time = ");
        System.out.printf("%.0f", obj2ObjTime);
        System.out.println("");
        System.out.print("Object 2 XML Time = ");
        System.out.printf("%.0f", obj2XmlTime);
        System.out.println("");
        System.out.print("Total Time = ");
        System.out.printf("%.0f", totalTime);
        System.out.println("\n**************         END METRICS PRINT     **********************");

        if (enableLog) {
            System.out.println("**************         START DEBUG PRINT     **********************");
            System.out.println(metricsBuilder.toString());
            System.out.println("**************         END DEBUG PRINT     **********************");
        }
    }

    private double avgTime(List<Long> xml2ObjectMetrics) {
        long sum = 0;
        for (int i = 0; i < xml2ObjectMetrics.size(); i++) {
            sum += xml2ObjectMetrics.get(i);
        }

        return (double) sum / xml2ObjectMetrics.size();
    }

}
