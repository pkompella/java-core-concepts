package net.atpco.translation;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

/**
 * Created by atp1pak on 4/1/2015.
 */
public class CSVFileGenerator {
    //Delimiter used in CSV file
    private static final String COMMA_DELIMITER = ",";
    private static final String NEW_LINE_SEPARATOR = "\n";
    //CSV file header
    private static final String FILE_HEADER = "File Size, #Fields, #Lookups, #Format-Fields, #Derived-Fields, #Groups, #Time";

    public void generateReport(String fileName, List<Report> reports) {
        FileWriter fileWriter = null;
        try {
            fileWriter = new FileWriter(fileName, true);
            //Write the CSV file header
            StringBuilder sb = new StringBuilder();

            //sb.append(FILE_HEADER.toString());

            //Add a new line separator after the header
            //sb.append(NEW_LINE_SEPARATOR);
            for (Report report : reports) {
                sb.append(String.valueOf(report.getFileSize()));
                sb.append(COMMA_DELIMITER);
                sb.append(String.valueOf(report.getFields()));
                sb.append(COMMA_DELIMITER);
                sb.append(String.valueOf(report.getLookups()));
                sb.append(COMMA_DELIMITER);
                sb.append(String.valueOf(report.getFormatFields()));
                sb.append(COMMA_DELIMITER);
                sb.append(String.valueOf(report.getDerivedFields()));
                sb.append(COMMA_DELIMITER);
                sb.append(String.valueOf(report.getGroups()));
                sb.append(COMMA_DELIMITER);
                sb.append(String.valueOf(report.getTime()));
                sb.append(NEW_LINE_SEPARATOR);
            }
            //sb.insert(0, FILE_HEADER.toString()).append(NEW_LINE_SEPARATOR);
            fileWriter.append(sb.toString());
        } catch (Exception e) {
            System.out.println("Error in CSVFileGenerator !!!");
            e.printStackTrace();
        } finally {

            try {
                fileWriter.flush();
                fileWriter.close();
            } catch (IOException e) {
                System.out.println("Error while flushing/closing fileWriter !!!");
                e.printStackTrace();
            }

        }
    }

}
