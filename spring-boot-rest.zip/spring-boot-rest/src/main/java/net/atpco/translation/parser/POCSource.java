package net.atpco.translation.parser;


import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by atp1pak on 3/31/2015.
 */
public class POCSource {
    @Getter  @Setter
    private List<Group> groups;
    public Group getCurrentGroup(){
        return groups.get(groups.size()-1);
    }
    public void prepareForGroup(){
        if (groups==null){
            groups = new ArrayList<Group>();
        }
        Group current = new Group();
        groups.add(current);
    }
}
