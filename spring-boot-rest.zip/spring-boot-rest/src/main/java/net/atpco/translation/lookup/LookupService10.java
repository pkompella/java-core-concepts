package net.atpco.translation.lookup;

import java.util.HashMap;
import java.util.Map;

public class LookupService10 implements LookupService {
	private static LookupService10 lookupService = null;
	private Map<String, String> serviceMap = new HashMap<>();
    private LookupService10() {
    	//load 10K records in to Map
    	for (int i = 0; i < 10000; i++) {
    		String key = "lookup 1:" + (i+1);
        	serviceMap.put(key, "For Key Code:" + key + ",  Descr: FareClass Description " + (i+1));
        }
    }
    
    public static LookupService getInstance() {
        if (lookupService == null) {
            lookupService = new LookupService10();
        }
        return lookupService;
    }
    
    public String lookup(String key) {
        return serviceMap.get(key);
    }

}
