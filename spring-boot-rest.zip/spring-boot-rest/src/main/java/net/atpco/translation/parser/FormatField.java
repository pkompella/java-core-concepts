package net.atpco.translation.parser;

import lombok.Getter;
import lombok.Setter;

public class FormatField {
	@Getter @Setter
    private String value;
}
