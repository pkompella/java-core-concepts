package net.atpco.translation.lookup;


public interface LookupService {
	String lookup(String key) ;
}
