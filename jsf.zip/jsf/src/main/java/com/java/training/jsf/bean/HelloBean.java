package com.java.training.jsf.bean;

import javax.faces.bean.ManagedBean;

@ManagedBean(name = "helloBean", eager = false)
public class HelloBean {
   public HelloBean() {
      System.out.println("Hello Bean started!");
   }
   public String getMessage() {
      return "Hello ... I am managed Bean!";
   }
   
   public String getMessage2() {
	   return "Hello ... I am managed Bean! - Message2";
   }
}