package com.java.training.spring.hibernate;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.java.training.spring.hibernate.bo.EmployeeBO;
import com.java.training.spring.hibernate.entity.Employee;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		ApplicationContext appContext = 
		    	  new ClassPathXmlApplicationContext("config/BeanLocations.xml");
			
		    	EmployeeBO employeeBO = (EmployeeBO)appContext.getBean("employeeBO");
		    	

		    	Employee employee = new Employee();
		    	employee.setId(1200);
		    	employee.setFname("First Name 1200");
		    	employee.setLname("Last Name 1200");
		    	employee.setAge(45);
		    	employee.setAddress("Sample Address 1200, City, State ZIP");
		    	employeeBO.save(employee);
		    	
		    	/*//** select **//*
		    	Employee employee2 = employeeBO.findByEmployeeId(1000);
		    	System.out.println(employee2);
*/		    	
		    	/** update **/
		    	//Employee employee2 = employeeBO.findByEmployeeId(1001);
		    	//employee2.setFname("First Name Updated 1001");
		    	//employeeBO.update(employee2);
		    	
		    	/** delete **/
		    	//employeeBO.delete(employee2);
		    	
		    	System.out.println("Done");
	}
}
