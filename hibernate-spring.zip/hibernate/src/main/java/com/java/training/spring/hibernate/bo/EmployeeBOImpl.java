package com.java.training.spring.hibernate.bo;

import com.java.training.spring.hibernate.entity.Employee;
import com.java.training.spring.hibernate.dao.EmployeeDAO;

public class EmployeeBOImpl implements EmployeeBO {
	
	//Spring Injection
	EmployeeDAO employeeDAO;
	
	public void setEmployeeDAO(EmployeeDAO employeeDAO) {
		this.employeeDAO = employeeDAO;
				
	}
	

	public void save(Employee employee) {
		employeeDAO.save(employee);
		
	}

	public void update(Employee employee) {
		employeeDAO.update(employee);
		
	}

	public void delete(Employee employee) {
		employeeDAO.delete(employee);
		
	}

	public Employee findByEmployeeId(int empId) {
		return employeeDAO.findByEmpId(empId);
	}

}
