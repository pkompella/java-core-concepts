package com.java.training.spring.hibernate.bo;

import com.java.training.spring.hibernate.entity.Employee;

public interface EmployeeBO {
	void save(Employee employee);
	
	void update(Employee employee);
	
	void delete(Employee employee);
	
	Employee findByEmployeeId(int empId);

}
