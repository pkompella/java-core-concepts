package com.java.training.spring.hibernate.dao;

import com.java.training.spring.hibernate.entity.Employee;

public interface EmployeeDAO {
	void save(Employee employee);
	
	void update(Employee employee);
	
	void delete(Employee employee);
	
	Employee findByEmpId(int empId);

}
