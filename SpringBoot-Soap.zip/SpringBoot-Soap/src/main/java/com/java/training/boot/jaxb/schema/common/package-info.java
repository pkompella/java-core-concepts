/**
 * Created by atp1pak on 7/19/2016.
 */
@XmlSchema(namespace = "http://www.iTech.com/employee/portal",
        xmlns = {
                @XmlNs(namespaceURI = "http://www.iTech.com/employee/portal", prefix = "")
        },
        elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.java.training.boot.jaxb.schema.common;

import javax.xml.bind.annotation.XmlNs;
import javax.xml.bind.annotation.XmlSchema;