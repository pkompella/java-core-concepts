package com.java.training.boot;

import com.java.training.boot.bo.EmployeeBO;
import com.java.training.boot.bo.EmployeeBOImpl;
import com.java.training.boot.service.EmployeeService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class Application {

    public static void main(String[] args) {
        ApplicationContext ctx = SpringApplication.run(Application.class, args);
        	
    }
}