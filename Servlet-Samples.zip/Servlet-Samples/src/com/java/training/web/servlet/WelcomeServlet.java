package com.java.training.web.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class WelcomeServlet extends HttpServlet {
	private String message;

	public void init() throws ServletException {
		// Do required initialization
		System.out.println("init() called");
		message = "Hello World!";
	}

	public void destroy() {
		// do nothing.
		System.out.println("destroy() called");
	}

	@Override
	protected void service(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException {
		System.out.println("service() called");
		super.service(arg0, arg1);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// Set response content type
		response.setContentType("text/html");

		String fname = request.getParameter("fname");
		String lname = request.getParameter("lname");

		// Actual logic goes here.
		PrintWriter out = response.getWriter();
		out.println("<h1>" + message + new Date().toString() + "</h1>");
		out.println("<h3>" + " ...our first servlet!" + "</h3>");
		out.println("<h6>" + " First Name = " + fname + "</h6>");
		out.println("<h6>" + " Last Name = " + lname + "</h6>");
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// Set response content type
		response.setContentType("text/html");

		String fname = request.getParameter("fname");
		String lname = request.getParameter("lname");

		// Actual logic goes here.
		PrintWriter out = response.getWriter();
		out.println("<h1>" + message + new Date().toString() + "</h1>");
		out.println("<h3>" + " ...our first servlet!" + "</h3>");
		out.println("<h6>" + " First Name = " + fname + "</h6>");
		out.println("<h6>" + " Last Name = " + lname + "</h6>");

	}

}
